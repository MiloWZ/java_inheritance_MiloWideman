package java_inheritance_MiloWideman;

public interface Person {

	
	public String getName();

	public String getDetails();
	}