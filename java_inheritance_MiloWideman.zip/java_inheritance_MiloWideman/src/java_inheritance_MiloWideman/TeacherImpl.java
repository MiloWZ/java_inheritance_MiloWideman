package java_inheritance_MiloWideman;

class cTeacherImpl extends PersonBaseImpl implements Teacher
{
private String thoughtCourseTitle;

public cTeacherImpl(String _name,String _thoughtCourseTitle)
{
   super(_name);
   thoughtCourseTitle = _thoughtCourseTitle;
}

public String teachesFor()
{
   return thoughtCourseTitle;
}
public String getDetails()
{
   return "teacher";
}
}

interface Student extends Person
{
public String studiesFor();
}

class StudentImpl extends PersonBaseImpl implements Student
{
private String takenCourseTitle;

public StudentImpl(String _name,String _takenCourseTitle)
{
super(_name);
takenCourseTitle = _takenCourseTitle;
}
public String studiesFor()
{
   return takenCourseTitle;
}
public String getDetails()
{
   return "student";
}
}

class MainEntry
{
   public static void main (String[] args)
   {
      
   Person p1, p2;
   Teacher t = new cTeacherImpl("ilker", "java");

   Student s = new StudentImpl("Milo","java");

   p1 = t;
   p2 = s;
  
   System.out.println("name of p1 and p2 : "+ p1.getName()+" "+ p2.getName());
   }
}