package java_inheritance_MiloWideman;


	public interface Teacher  extends Person
	{ 

		
		public String teachesFor();
		}
	

